class Enemigo extends Personaje {
    public Enemigo(String name, int hp, int attackPower) {
        super(name, hp, attackPower);
    }
}
